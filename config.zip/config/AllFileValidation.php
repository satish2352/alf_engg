<?php

namespace App\Constants;

return [
    
    'SIGNATURE_IMAGE_MAX_SIZE'=>'1024',
    'SIGNATURE_IMAGE_MIN_SIZE'=>'1',
    
];