<?php

return [
     'PAGINATION' => env('EMPLOYEES_PAGINATION', 10), 

     'EMPLOYEE_SIGNATURE_ADD' => 'app/public/upload/images/signature/',

    
    'EMPLOYEE_SIGNATURE_DELETE'	         => '/upload/images/signature/',
    'EMPLOYEE_SIGNATURE_VIEW'	         => env("FILE_VIEW").'/upload/images/signature/',
];

