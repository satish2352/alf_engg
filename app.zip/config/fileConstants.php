<?php

namespace App\Constants;

return [
     'PAGINATION' => env('EMPLOYEES_PAGINATION', 10), 
];