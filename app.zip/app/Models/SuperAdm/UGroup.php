<?php

namespace App\Models\SuperAdm;

use Illuminate\Database\Eloquent\Model;

class UGroup extends Model
{
    protected $table='u_group';
    protected $primeryKey='id';
    public $timestamps=false;
    protected $fillable=[];
}
