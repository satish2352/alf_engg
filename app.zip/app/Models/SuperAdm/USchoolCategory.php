<?php

namespace App\Models\SuperAdm;

use Illuminate\Database\Eloquent\Model;

class USchoolCategory extends Model
{
    protected $table='u_schoolcategory';
    protected $primeryKey='id';
    public $timestamps=false;
    protected $fillable=[];
}
