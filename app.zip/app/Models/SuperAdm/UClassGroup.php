<?php

namespace App\Models\SuperAdm;

use Illuminate\Database\Eloquent\Model;

class UClassGroup extends Model
{
    protected $table='u_classgroup';
    protected $primeryKey='id';
    public $timestamps=false;
    protected $fillable=[];
}
