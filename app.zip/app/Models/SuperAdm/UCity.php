<?php

namespace App\Models\SuperAdm;

use Illuminate\Database\Eloquent\Model;

class UCity extends Model
{
    protected $table='u_city';
    protected $primeryKey='id';
    public $timestamps=false;
    protected $fillable=[];
}
