<?php

namespace App\Models\SuperAdm;

use Illuminate\Database\Eloquent\Model;

class UClass extends Model
{
    protected $table='u_class';
    protected $primeryKey='id';
    public $timestamps=false;
    protected $fillable=[];
}
