<?php

namespace App\Models\SuperAdm;

use Illuminate\Database\Eloquent\Model;

class UState extends Model
{
    protected $table='u_state';
    protected $primeryKey='id';
    public $timestamps=false;
    protected $fillable=[];
}
