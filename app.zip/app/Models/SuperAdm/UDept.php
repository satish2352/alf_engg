<?php

namespace App\Models\SuperAdm;

use Illuminate\Database\Eloquent\Model;

class UDept extends Model
{
    protected $table='u_dept';
    protected $primeryKey='id';
    public $timestamps=false;
    protected $fillable=[];
}
