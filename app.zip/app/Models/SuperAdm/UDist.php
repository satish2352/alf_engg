<?php

namespace App\Models\SuperAdm;

use Illuminate\Database\Eloquent\Model;

class UDist extends Model
{
    protected $table='u_dist';
    protected $primeryKey='id';
    public $timestamps=false;
    protected $fillable=[];
}
