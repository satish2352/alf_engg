<?php

namespace App\Models\SuperAdm;

use Illuminate\Database\Eloquent\Model;

class AcdmcYear extends Model
{
	protected $table='u_academicyear';
    protected $primeryKey='id';
    public $timestamps=false;
    protected $fillable=[];
}