<?php

namespace App\Http\Repository\Superadm;
use Illuminate\Http\Request;
use App\Models\SuperAdm\MSchool;
use App\Models\SuperAdm\AcdmcYear;
use App\Models\SuperAdm\UClass;
class DashboardRepository
{
	
}